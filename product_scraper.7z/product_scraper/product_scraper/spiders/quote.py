import scrapy


class QuoteSpider(scrapy.Spider):
    name = 'quote'
    allowed_domains = ['rasputin96.ru']
    start_urls = ['http://rasputin96.ru/']

    def parse(self, response):
        yield from response.follow_all(css='ul.menu-v a', callback=self.category_parse)

    def category_parse(self, response):
        yield from response.follow_all(css='ul.product-list a', callback=self.product_list_parse)

    def product_list_parse(self, response):
        yield from response.follow_all(css='ul.product-list a', callback=self.product_parse)
        if response.css('ul.menu-h li a::attr(href)')[-1].get().split('?')[1] != response.url.split('?')[1]:
            page = response.css('ul.menu-h li a::attr(href)')[-1]
            yield from response.follow_all(page, callback=self.product_parse)

    def product_parse(self, response):
        products = response.css('ul.product-list')
        yield {
            'title': response.css('title::text').get(),
            'price': response.css('div.add2cart span.price::text').get().strip(),
            'description': response.css('div.description p::text').getall(),
            'features_name': response.css('table.features td.name::text').getall(),
            'features_value': response.css('table.features td.value::text').getall(),
            'categoryes': response.css('div.prduct-info p a::text').getall(),
            'buy_also': products[0].css('div.image a::attr(href)').getall(),
            'see_also': products[1].css('div.image a::attr(href)').getall()
        }