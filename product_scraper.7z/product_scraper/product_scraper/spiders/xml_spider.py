from scrapy.spiders.sitemap import SitemapSpider


class XMLSpider(SitemapSpider):
    name = 'xmlspider'
    sitemap_urls = ['http://rasputin96.ru/sitemap-shop.xml']

    def parse(self, response):
        for quote in response.css('body')[10]:
            yield {
                'text': quote.css('main.div.div.h1.span::text').get(),
                'author': quote.css('main.div.div.nav.a::text').get(),
                'tags': quote.css('div.tags a.tag::text').getall(),
            }
